export const selectData = (state) => state.data; // Assuming 'data' is the slice of state where your data is stored
